import "./App.css";
import { useState } from "react";

function App() {
  const [formInput, setFormInput] = useState({
    email: "",
    ssubject: "",
    htmlBody: "",
  });

  const mailHandler = (event) => {
    setFormInput({ ...formInput, email: event.target.value });
  };
  const subjectHandler = (event) => {
    setFormInput({ ...formInput, subject: event.target.value });
  };
  const bodyHandler = (event) => {
    console.log(event.target.value);
    setFormInput({ ...formInput, htmlBody: event.target.value });
  };

  const sendMailHandler = async (event) => {
    event.preventDefault();
    console.log("------------>", formInput);
    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formInput),
    };
    const sendMail = await fetch(
      `http://localhost:8000/sendMail`,
      requestOptions
    );
    const responce = await sendMail.json();
    console.log("------------>>>", responce);
  };
  return (
    <div className="App">
      <form onSubmit={sendMailHandler} className="App-header">
        <input
          type="text"
          className="ipt-mail"
          placeholder="example@mail.com"
          onChange={mailHandler}
        />
        <input
          type="text"
          className="ipt-mail"
          placeholder="Subject"
          onChange={subjectHandler}
        />
        <textarea
          rows="4"
          cols="50"
          className="ipt-box"
          placeholder="Email body"
          onChange={bodyHandler}
        ></textarea>
        <button className="btn-mail">Send mail</button>
      </form>
    </div>
  );
}

export default App;
